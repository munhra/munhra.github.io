		console.log('loding model 2');
		//////////////////////////////////////////////////////////////////////////////////
		//		Init
		//////////////////////////////////////////////////////////////////////////////////
		// init renderer
		
	
	
		var renderer	= new THREE.WebGLRenderer({
			antialias: true,
			alpha: true
		});
		renderer.setClearColor(new THREE.Color('lightgrey'), 0)
		renderer.setSize( 640, 480 );
		renderer.domElement.style.position = 'absolute'
		renderer.domElement.style.top = '0px'
		renderer.domElement.style.left = '0px'


		renderer.gammaOutput = true;
			// renderer.setClearColor( 0x000000 );
		//	renderer.setPixelRatio( window.devicePixelRatio );

		document.body.appendChild( renderer.domElement );
		// array of functions for the rendering loop
		var onRenderFcts= [];
		// init scene and camera
		var scene	= new THREE.Scene();

		//var scene_1 = new THREE.Scene();
			
		//////////////////////////////////////////////////////////////////////////////////
		//		Initialize a basic camera
		//////////////////////////////////////////////////////////////////////////////////
		// Create a camera
		var camera = new THREE.Camera();
		scene.add(camera);